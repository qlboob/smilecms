-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2014-12-25 14:04:58
-- 服务器版本： 5.6.20
-- PHP Version: 5.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scms`
--

-- --------------------------------------------------------

--
-- 表的结构 `s_block`
--

CREATE TABLE IF NOT EXISTS `s_block` (
`blk_id` int(10) unsigned NOT NULL,
  `sit_id` tinyint(3) unsigned NOT NULL COMMENT '站点：0表示所有站点',
  `blk_type` varchar(20) NOT NULL COMMENT 'block名字',
  `blk_title` varchar(100) NOT NULL COMMENT '区块标题',
  `blk_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态：0-不可用，1-可用',
  `blk_weight` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `blk_region` varchar(10) DEFAULT NULL COMMENT '所属区域',
  `blk_visibility` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-除下面所有页面可见，1-下列页面可见，2-code为true可见',
  `blk_page` varchar(255) DEFAULT NULL COMMENT '哪些页面可见或不可见',
  `blk_cachetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '缓存时间（单位秒）',
  `blk_param` text NOT NULL COMMENT 'block的参数',
  `blk_identify` varchar(50) NOT NULL COMMENT 'block的唯一标识',
  `blk_dependence` varchar(200) NOT NULL COMMENT '依赖的区块'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='区块';

-- --------------------------------------------------------

--
-- 表的结构 `s_event`
--

CREATE TABLE IF NOT EXISTS `s_event` (
`evt_id` int(11) NOT NULL COMMENT 'id',
  `sit_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '站点：0表示所有站点',
  `evt_status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可用',
  `evt_identify` varchar(50) NOT NULL COMMENT '事件的标识',
  `evt_tag` varchar(50) NOT NULL COMMENT '抛出事件名称',
  `evt_weight` tinyint(4) NOT NULL DEFAULT '0' COMMENT '权重执行的先后顺序',
  `evt_class` varchar(60) NOT NULL COMMENT '所要执行的类名',
  `evt_visibility` tinyint(1) NOT NULL DEFAULT '0' COMMENT '在哪些页面执行：0—除下列页面执行，1——下列页面执行',
  `evt_page` text NOT NULL COMMENT '定义的页面',
  `evt_visibility_and` tinyint(1) NOT NULL DEFAULT '0' COMMENT '和php代码的关系：0——或者，1——并且',
  `evt_php` varchar(255) NOT NULL DEFAULT '' COMMENT 'php代码执行结果'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `s_event`
--

INSERT INTO `s_event` (`evt_id`, `sit_id`, `evt_status`, `evt_identify`, `evt_tag`, `evt_weight`, `evt_class`, `evt_visibility`, `evt_page`, `evt_visibility_and`, `evt_php`) VALUES
(1, 0, 0, 'posabsolute', 'before_form_render', 0, 'Com\\Qinjq\\Form\\Validatoradapter\\SPosabsoluteValidatoradapter', 0, '', 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `s_form`
--

CREATE TABLE IF NOT EXISTS `s_form` (
`frm_id` int(11) unsigned NOT NULL,
  `sit_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '站点id',
  `frm_title` varchar(50) NOT NULL COMMENT '显示的名称',
  `frm_table` varchar(50) DEFAULT NULL COMMENT '关联的表名',
  `frm_attr` text COMMENT '属性',
  `frm_param` text COMMENT '表单序列化的配置',
  `frm_parent` varchar(100) DEFAULT NULL COMMENT '可以是多个表单的集合，逗号分隔'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='表单';

--
-- 转存表中的数据 `s_form`
--

INSERT INTO `s_form` (`frm_id`, `sit_id`, `frm_title`, `frm_table`, `frm_attr`, `frm_param`, `frm_parent`) VALUES
(1, 1, '表单', 'form', NULL, NULL, '2'),
(2, 1, 'Dev表单全局设定', '', NULL, NULL, ''),
(3, 1, '表单字段', 'formfield', NULL, NULL, '2'),
(4, 1, '模型', 'model', NULL, NULL, '2'),
(5, 1, '模型字段', 'modelfield', NULL, NULL, '3'),
(6, 1, '区块', 'block', NULL, NULL, '2'),
(7, 1, '表单数据填充', 'formfieldfill', NULL, NULL, NULL),
(8, 1, '表单字段提交转换', 'formfieldpostconvert', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `s_formdecorator`
--

CREATE TABLE IF NOT EXISTS `s_formdecorator` (
`fdr_id` int(10) unsigned NOT NULL,
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单ID',
  `ffd_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '表单字段ID',
  `fdr_type` varchar(20) NOT NULL COMMENT '修饰器类型',
  `fdr_param` text NOT NULL COMMENT '修饰器参数'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='表单修饰器';

--
-- 转存表中的数据 `s_formdecorator`
--

INSERT INTO `s_formdecorator` (`fdr_id`, `frm_id`, `ffd_id`, `fdr_type`, `fdr_param`) VALUES
(1, 2, 0, 'ForId', '');

-- --------------------------------------------------------

--
-- 表的结构 `s_formfield`
--

CREATE TABLE IF NOT EXISTS `s_formfield` (
`ffd_id` int(10) unsigned NOT NULL,
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单id',
  `ffd_name` varchar(50) NOT NULL COMMENT '字段的名字',
  `ffd_label` varchar(50) NOT NULL COMMENT 'label名字',
  `ffd_type` varchar(20) NOT NULL COMMENT '控件类型',
  `ffd_attr` text COMMENT '属性',
  `ffd_param` text COMMENT '表单字段的参数',
  `ffd_weight` smallint(6) NOT NULL,
  `ffd_display` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否在表单中显示',
  `ffd_parent` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父字段ID'
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='表单字段';

--
-- 转存表中的数据 `s_formfield`
--

INSERT INTO `s_formfield` (`ffd_id`, `frm_id`, `ffd_name`, `ffd_label`, `ffd_type`, `ffd_attr`, `ffd_param`, `ffd_weight`, `ffd_display`, `ffd_parent`) VALUES
(1, 1, 'frm_title', '标题', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(2, 1, 'frm_id', '', 'PresentHidden', NULL, NULL, 100, 1, 0),
(3, 1, 'frm_table', '表名', 'Text', NULL, NULL, 3, 1, 0),
(4, 1, 'frm_parent', '父表名', 'Hidden', NULL, NULL, 10, 1, 0),
(5, 2, '_submit', '', 'Submit', NULL, NULL, 99, 1, 0),
(8, 3, 'ffd_name', '字段名', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 2, 1, 0),
(9, 3, 'ffd_label', 'Label名字', 'Text', NULL, NULL, 4, 1, 0),
(10, 3, 'ffd_type', '输入控件类型', 'Select', NULL, 'a:1:{s:7:"options";s:356:"Text|单行文本框\r\nTextArea|多行文本框\r\nSelect|选择框\r\nCheckbox|复选框\r\nDCheckbox|复选框（有默认值）\r\nCheckboxes|复选组\r\nRadio|单选框\r\nRadios|单选组\r\nHidden|隐藏域\r\nPresentHidden|隐藏域（有值才出现）\r\nFile|文件域\r\nPassword|密码框\r\nLineBox|行容器\r\nFieldset|字段集\r\nHtml|代码\r\nValue|直接显示值 ";}', 8, 1, 0),
(11, 3, 'ffd_weight', '排序', 'Text', NULL, NULL, 30, 1, 0),
(12, 3, 'frm_id', '', 'Hidden', NULL, NULL, 200, 1, 0),
(13, 4, 'mdl_id', '', 'PresentHidden', NULL, NULL, 200, 1, 0),
(14, 4, 'sit_id', '站点', 'Select', NULL, 'a:2:{s:7:"options";s:33:"return D(''Site'')->getSelectList()";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(15, 4, 'mdl_name', '模型名称', 'Text', NULL, NULL, 0, 1, 0),
(16, 4, 'mdl_table', '表', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 3, 1, 0),
(17, 4, 'mdl_description', '模型描述', 'Text', NULL, NULL, 3, 1, 0),
(18, 4, 'mdl_parent', '', 'PresentHidden', NULL, NULL, 200, 1, 0),
(19, 5, 'mdf_id', '', 'PresentHidden', NULL, NULL, 200, 1, 0),
(20, 5, 'mdl_id', '', 'Hidden', NULL, NULL, 200, 1, 0),
(22, 5, 'mdf_listtitle', '后台列表标题', 'TextArea', NULL, NULL, 5, 1, 0),
(23, 5, 'mdf_weight', '后台列表排序', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 8, 1, 0),
(24, 3, 'param[options]', '选项内容', 'TextArea', NULL, NULL, 7, 1, 0),
(25, 3, 'validator[required]', '必填', 'DCheckbox', NULL, NULL, 8, 1, 0),
(26, 3, 'validator[maxlength]', '最大长度', 'Text', NULL, NULL, 50, 1, 0),
(27, 3, 'validator[minlength]', '最小长度', 'Text', NULL, NULL, 40, 1, 0),
(28, 3, 'validator[min]', '最小值', 'Text', NULL, NULL, 45, 1, 0),
(29, 3, 'validator[max]', '最大值', 'Text', NULL, NULL, 46, 1, 0),
(30, 3, 'validator[reg]', '正则', 'Select', NULL, 'a:1:{s:7:"options";s:104:"|\r\ndate|日期\r\nemail|邮箱\r\ninteger|整数\r\nip|IP\r\nnumber|小数\r\nurl|网址\r\ncustom|自定义正则  ";}', 60, 1, 0),
(31, 3, 'ffd_id', '', 'PresentHidden', NULL, NULL, 2000, 1, 0),
(32, 3, 'validator[unique]', '唯一值', 'Checkbox', NULL, NULL, 50, 1, 0),
(33, 3, 'validator[regular]', '自定义正则', 'Text', NULL, NULL, 70, 1, 0),
(34, 3, 'param[defaultValue]', '默认值', 'Text', NULL, NULL, 29, 1, 0),
(35, 6, 'blk_id', '', 'PresentHidden', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(36, 6, 'sit_id', '站点', 'Select', NULL, 'a:2:{s:7:"options";s:30:"0|所有站点\r\n1|系统站点";s:12:"defaultValue";s:1:"0";}', 32767, 1, 0),
(37, 6, 'blk_type', '', 'Hidden', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(38, 6, 'blk_title', '标题', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 8334, 1, 0),
(39, 6, 'blk_status', '状态', 'DCheckbox', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 25002, 1, 0),
(40, 6, 'blk_weight', '排序', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 32767, 1, 0),
(41, 6, 'blk_identify', '标识', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 16668, 1, 0),
(42, 1, 'sit_id', '站点', 'Select', NULL, 'a:2:{s:7:"options";s:33:"return D(''Site'')->getSelectList()";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(43, 4, 'frm_id', '', 'PresentHidden', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 200, 1, 0),
(44, 4, 'mdf_name', '主键', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 10, 1, 0),
(45, 5, 'mdl_datatype', '数据类型', 'Select', NULL, 'a:2:{s:7:"options";s:64:"|请选择\r\nINT|整数\r\nVARCHAR(255)|字符串\r\nTEXT|大文本\r\n";s:12:"defaultValue";s:0:"";}', 3, 1, 0),
(46, 7, 'fff_id', '', 'Hidden', NULL, NULL, 0, 1, 0),
(48, 7, 'fff_title', '标题', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(49, 7, 'ffd_id', '', 'Hidden', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(50, 7, 'fff_type', '填充类型', 'Select', NULL, 'a:2:{s:7:"options";s:44:"|请选择\r\nfunction|函数\r\nconst|固定值";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(51, 7, 'fff_content', '内容', 'TextArea', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(52, 8, 'fpc_id', '', 'Hidden', NULL, NULL, 0, 1, 0),
(53, 8, 'ffd_id', '', 'PresentHidden', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(54, 8, 'fpc_title', '标题', 'Text', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(55, 8, 'fpc_type', '类型', 'Select', NULL, 'a:2:{s:7:"options";s:40:"|请选择\r\nfunction|函数\r\ncode|代码";s:12:"defaultValue";s:0:"";}', 0, 1, 0),
(56, 8, 'fpc_content', '内容', 'TextArea', NULL, 'a:2:{s:7:"options";s:0:"";s:12:"defaultValue";s:0:"";}', 0, 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `s_formfieldconvert`
--

CREATE TABLE IF NOT EXISTS `s_formfieldconvert` (
`ffc_id` int(10) unsigned NOT NULL,
  `ffc_type` varchar(10) NOT NULL COMMENT '提交转换或显示转换',
  `ffc_code` varchar(255) NOT NULL COMMENT '代码',
  `ffc_title` varchar(20) NOT NULL COMMENT '标题',
  `ffd_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '字段ID',
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `s_formfieldfill`
--

CREATE TABLE IF NOT EXISTS `s_formfieldfill` (
`fff_id` int(10) unsigned NOT NULL,
  `ffd_id` int(11) unsigned NOT NULL COMMENT '表单字段ID',
  `fff_title` varchar(20) NOT NULL COMMENT '标题',
  `fff_type` varchar(50) NOT NULL COMMENT '充填的类型|字符串|函数',
  `fff_content` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `s_formfieldpostconvert`
--

CREATE TABLE IF NOT EXISTS `s_formfieldpostconvert` (
`fpc_id` int(10) unsigned NOT NULL,
  `ffd_id` int(11) NOT NULL COMMENT '字段ID',
  `fpc_title` varchar(50) NOT NULL COMMENT '标题',
  `fpc_type` varchar(255) NOT NULL COMMENT '类型',
  `fpc_content` varchar(255) NOT NULL COMMENT '内容'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `s_formfieldwidget`
--

CREATE TABLE IF NOT EXISTS `s_formfieldwidget` (
`ffw_id` int(10) unsigned NOT NULL,
  `ffd_id` int(10) unsigned NOT NULL COMMENT '表单元素id',
  `ffw_name` varchar(20) NOT NULL COMMENT '控件名',
  `ffw_param` text NOT NULL COMMENT '控件参数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表单控件';

-- --------------------------------------------------------

--
-- 表的结构 `s_formrender`
--

CREATE TABLE IF NOT EXISTS `s_formrender` (
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单id',
  `fmr_type` varchar(10) NOT NULL COMMENT '类型',
  `fmr_param` text NOT NULL COMMENT '参数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='渲染器';

--
-- 转存表中的数据 `s_formrender`
--

INSERT INTO `s_formrender` (`frm_id`, `fmr_type`, `fmr_param`) VALUES
(2, 'Div', 'a:7:{s:9:"formClass";s:15:"form-horizontal";s:9:"lineClass";s:10:"form-group";s:10:"labelClass";s:22:"col-sm-2 control-label";s:13:"inputDivClass";s:8:"col-sm-9";s:10:"inputClass";s:12:"form-control";s:11:"buttonClass";s:15:"btn btn-primary";s:15:"emptyLabelClass";s:18:"col-sm-2 invisible";}');

-- --------------------------------------------------------

--
-- 表的结构 `s_formvalidator`
--

CREATE TABLE IF NOT EXISTS `s_formvalidator` (
`fvd_id` int(10) unsigned NOT NULL,
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单ID',
  `ffd_id` int(10) unsigned NOT NULL COMMENT '字段ID',
  `fvd_type` varchar(20) NOT NULL COMMENT '验证类型',
  `fvd_target` varchar(50) NOT NULL COMMENT '被用来比较的值',
  `fvd_msg` varchar(30) DEFAULT NULL COMMENT '错误提示',
  `fvd_param` text COMMENT '参数'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `s_formvalidator`
--

INSERT INTO `s_formvalidator` (`fvd_id`, `frm_id`, `ffd_id`, `fvd_type`, `fvd_target`, `fvd_msg`, `fvd_param`) VALUES
(1, 6, 41, 'required', '', NULL, NULL),
(2, 6, 41, 'unique', '', NULL, NULL),
(3, 4, 14, 'required', '', NULL, NULL),
(4, 4, 44, 'required', '', NULL, NULL),
(5, 4, 44, 'regular', '^[a-z]\\w*$', NULL, NULL),
(6, 5, 45, 'required', '', NULL, NULL),
(7, 5, 23, 'integer', '', NULL, NULL),
(8, 4, 16, 'required', '', NULL, NULL),
(9, 1, 1, 'required', '', NULL, NULL),
(10, 3, 8, 'required', '', NULL, NULL),
(12, 7, 48, 'required', '', NULL, NULL),
(13, 7, 50, 'required', '', NULL, NULL),
(14, 7, 51, 'required', '', NULL, NULL),
(15, 8, 54, 'required', '', NULL, NULL),
(16, 8, 55, 'required', '', NULL, NULL),
(17, 8, 56, 'required', '', NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `s_formvalidatoradapter`
--

CREATE TABLE IF NOT EXISTS `s_formvalidatoradapter` (
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单ID',
  `fva_type` varchar(20) NOT NULL COMMENT '表单验证适配器类型',
  `fva_param` text NOT NULL COMMENT '表单验证适配器参数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表单验证适配器';

--
-- 转存表中的数据 `s_formvalidatoradapter`
--

INSERT INTO `s_formvalidatoradapter` (`frm_id`, `fva_type`, `fva_param`) VALUES
(2, 'Posabsolute', '');

-- --------------------------------------------------------

--
-- 表的结构 `s_model`
--

CREATE TABLE IF NOT EXISTS `s_model` (
`mdl_id` int(11) unsigned NOT NULL,
  `sit_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '站点',
  `mdl_name` varchar(20) NOT NULL COMMENT '模型名称',
  `mdl_table` varchar(30) NOT NULL COMMENT '表名',
  `mdl_description` varchar(50) DEFAULT NULL COMMENT '描述',
  `frm_id` int(10) unsigned NOT NULL COMMENT '表单ID',
  `mdl_parent` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父id'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='模型';

--
-- 转存表中的数据 `s_model`
--

INSERT INTO `s_model` (`mdl_id`, `sit_id`, `mdl_name`, `mdl_table`, `mdl_description`, `frm_id`, `mdl_parent`) VALUES
(1, 1, '表单', 'form', '表单', 1, 0),
(2, 1, '表单字段', 'formfield', '表单字段', 3, 0),
(3, 1, '模型', 'model', NULL, 4, 0),
(4, 1, '模型字段', 'modelfield', NULL, 5, 0),
(5, 1, '区块', 'block', '区块', 6, 0),
(6, 1, '表单数据填充', 'formfieldfill', '表单数据填充', 7, 0),
(7, 1, '表单字段提交转换', 'formfieldpostconvert', '表单字段提交转换', 8, 0);

-- --------------------------------------------------------

--
-- 表的结构 `s_modelfield`
--

CREATE TABLE IF NOT EXISTS `s_modelfield` (
`mdf_id` int(10) unsigned NOT NULL,
  `mdl_id` int(10) unsigned NOT NULL,
  `mdf_name` varchar(20) NOT NULL COMMENT '列名',
  `mdf_weight` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0后台不显示，显示的顺序',
  `mdf_listtitle` text COMMENT '后台列表显示列名'
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='模型字段';

--
-- 转存表中的数据 `s_modelfield`
--

INSERT INTO `s_modelfield` (`mdf_id`, `mdl_id`, `mdf_name`, `mdf_weight`, `mdf_listtitle`) VALUES
(1, 2, 'ffd_id', 0, '#\r\n\r\n操作\r\n<a href="<?php echo U(''Dev/Formfield/edit'',array(''id''=>$v[''ffd_id'']));?>" data-toggle="tooltip" title="编辑"><i class="glyphicon glyphicon-edit"></i></a>'),
(2, 2, 'ffd_label', 3, 'Label名'),
(3, 2, 'ffd_name', 4, '字段名'),
(4, 2, 'ffd_type', 5, '输入类型'),
(5, 2, 'ffd_weight', 6, '顺序'),
(6, 2, 'ffd_parent', 7, '父ID'),
(7, 4, 'mdf_id', 0, '#\r\n\r\n操作\r\n<a href="<?php echo U(''Dev/Modelfield/edit'',array(''id''=>$v[''mdf_id'']));?>" data-toggle="tooltip" title="编辑"><i class="glyphicon glyphicon-edit"></i></a>\r\n<a href="<?php echo U(''Dev/Modelfield/add'',array(''mdl_id''=>$v[''mdl_id'']));?>" data-toggle="tooltip" title="增加子字段"><i class="glyphicon glyphicon-plus-sign"></i></a>'),
(8, 4, 'mdl_id', 0, ''),
(9, 4, 'mdf_name', 1, '模型字段'),
(10, 4, 'mdf_weight', 5, '排序'),
(11, 4, 'mdf_listtitle', 6, ''),
(12, 3, 'mdl_id', 0, '#\r\n\r\n操作\r\n<a href="<?php echo U(''Dev/Model/edit'',array(''id''=>$v[''mdl_id'']));?>" data-toggle="tooltip" title="编辑"><i class="glyphicon glyphicon-edit"></i></a>\r\n<a href="<?php echo U(''Dev/Modelfield/add'',array(''mdl_id''=>$v[''mdl_id'']));?>" data-toggle="tooltip" title="增加字段"><i class="glyphicon glyphicon-plus-sign"></i></a>\r\n<a href="<?php echo U(''Dev/Modelfield/index'',array(''mdl_id''=>$v[''mdl_id'']));?>" data-toggle="tooltip" title="字段列表"><i class="glyphicon glyphicon-th-list"></i></a>'),
(13, 3, 'sit_id', 1, '站点ID'),
(14, 3, 'mdl_name', 2, '模型名\r\n|'),
(15, 3, 'mdl_table', 3, '表名\r\n|'),
(16, 3, 'mdl_description', 4, ''),
(17, 3, 'frm_id', 5, '表单ID'),
(18, 3, 'mdl_parent', 6, ''),
(19, 5, 'blk_id', 0, '#\r\n\r\n操作\r\n<a href="<?php echo U(''Dev/Block/edit'',array(''id''=>$v[''blk_id'']));?>" data-toggle="tooltip" title="编辑"><i class="glyphicon glyphicon-edit"></i></a>'),
(20, 1, 'frm_id', 0, '#\r\n\r\n操作\r\n<a href="<?php echo U(''Dev/Form/edit'',array(''id''=>$v[''frm_id'']));?>" data-toggle="tooltip" title="编辑"> <i class="glyphicon glyphicon-edit"></i> </a>\r\n<a href="<?php echo U(''Dev/Param/edit'',array(''id''=>$v[''frm_id''],''table''=>''form''));?>" data-toggle="tooltip" title="参数设置"> <i class="glyphicon glyphicon-cog"></i> </a>\r\n<a href="<?php echo U(''Dev/Form/add'',array(''frm_parent''=>$v[''frm_id'']));?>" data-toggle="tooltip" title="创建子表单"> <i class="glyphicon glyphicon-share"></i> </a> <a href="<?php echo U(''Dev/Formfield/index'',array(''frm_id''=>$v[''frm_id'']));?>" data-toggle="tooltip" title="字段列表"> <i class="glyphicon glyphicon-th-list"></i> </a>\r\n<a href="<?php echo U(''Dev/Formfield/add'',array(''frm_id''=>$v[''frm_id'']));?>" data-toggle="tooltip" title="增加字段"> <i class="glyphicon glyphicon-plus-sign"> </i> </a>\r\n'),
(21, 1, 'frm_title', 4, '名称'),
(22, 1, 'frm_table', 6, '数据表'),
(23, 1, 'frm_parent', 10, '父表单'),
(24, 1, 'sit_id', 20, '站点ID'),
(25, 6, 'fff_title', 0, '标题'),
(27, 6, 'ffd_id', 0, ''),
(28, 6, 'fff_type', 2, '填充类型'),
(29, 6, 'fff_content', 0, ''),
(30, 7, 'ffd_id', 0, ''),
(31, 7, 'fpc_title', 0, '标题'),
(32, 7, 'fpc_type', 0, '类型'),
(33, 7, 'fpc_content', 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `s_site`
--

CREATE TABLE IF NOT EXISTS `s_site` (
`sit_id` int(10) unsigned NOT NULL,
  `sit_name` varchar(20) NOT NULL COMMENT '站点名称',
  `sit_domain` varchar(30) NOT NULL COMMENT '站点域名',
  `sit_table_pre` varchar(20) NOT NULL COMMENT '数据表前缀'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='站点';

--
-- 转存表中的数据 `s_site`
--

INSERT INTO `s_site` (`sit_id`, `sit_name`, `sit_domain`, `sit_table_pre`) VALUES
(1, '系统', '', 's_');

-- --------------------------------------------------------

--
-- 表的结构 `s_theme`
--

CREATE TABLE IF NOT EXISTS `s_theme` (
`thm_id` int(10) unsigned NOT NULL,
  `thm_name` varchar(20) NOT NULL,
  `thm_title` varchar(20) NOT NULL,
  `thm_region` varchar(255) NOT NULL DEFAULT 'head|页面开始 header|头部 left|左边栏 right|右边栏 con_top|内容上部 con_bottom|内容下部 footer|页脚 closure|页面结束'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='主题';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `s_block`
--
ALTER TABLE `s_block`
 ADD PRIMARY KEY (`blk_id`);

--
-- Indexes for table `s_event`
--
ALTER TABLE `s_event`
 ADD PRIMARY KEY (`evt_id`);

--
-- Indexes for table `s_form`
--
ALTER TABLE `s_form`
 ADD PRIMARY KEY (`frm_id`);

--
-- Indexes for table `s_formdecorator`
--
ALTER TABLE `s_formdecorator`
 ADD PRIMARY KEY (`fdr_id`);

--
-- Indexes for table `s_formfield`
--
ALTER TABLE `s_formfield`
 ADD PRIMARY KEY (`ffd_id`);

--
-- Indexes for table `s_formfieldconvert`
--
ALTER TABLE `s_formfieldconvert`
 ADD PRIMARY KEY (`ffc_id`);

--
-- Indexes for table `s_formfieldfill`
--
ALTER TABLE `s_formfieldfill`
 ADD PRIMARY KEY (`fff_id`);

--
-- Indexes for table `s_formfieldpostconvert`
--
ALTER TABLE `s_formfieldpostconvert`
 ADD PRIMARY KEY (`fpc_id`);

--
-- Indexes for table `s_formfieldwidget`
--
ALTER TABLE `s_formfieldwidget`
 ADD PRIMARY KEY (`ffw_id`);

--
-- Indexes for table `s_formrender`
--
ALTER TABLE `s_formrender`
 ADD PRIMARY KEY (`frm_id`);

--
-- Indexes for table `s_formvalidator`
--
ALTER TABLE `s_formvalidator`
 ADD PRIMARY KEY (`fvd_id`);

--
-- Indexes for table `s_formvalidatoradapter`
--
ALTER TABLE `s_formvalidatoradapter`
 ADD PRIMARY KEY (`frm_id`);

--
-- Indexes for table `s_model`
--
ALTER TABLE `s_model`
 ADD PRIMARY KEY (`mdl_id`);

--
-- Indexes for table `s_modelfield`
--
ALTER TABLE `s_modelfield`
 ADD PRIMARY KEY (`mdf_id`);

--
-- Indexes for table `s_site`
--
ALTER TABLE `s_site`
 ADD PRIMARY KEY (`sit_id`), ADD UNIQUE KEY `sit_name` (`sit_name`), ADD UNIQUE KEY `sit_domain` (`sit_domain`);

--
-- Indexes for table `s_theme`
--
ALTER TABLE `s_theme`
 ADD PRIMARY KEY (`thm_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `s_block`
--
ALTER TABLE `s_block`
MODIFY `blk_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `s_event`
--
ALTER TABLE `s_event`
MODIFY `evt_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `s_form`
--
ALTER TABLE `s_form`
MODIFY `frm_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `s_formdecorator`
--
ALTER TABLE `s_formdecorator`
MODIFY `fdr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `s_formfield`
--
ALTER TABLE `s_formfield`
MODIFY `ffd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `s_formfieldconvert`
--
ALTER TABLE `s_formfieldconvert`
MODIFY `ffc_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `s_formfieldfill`
--
ALTER TABLE `s_formfieldfill`
MODIFY `fff_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `s_formfieldpostconvert`
--
ALTER TABLE `s_formfieldpostconvert`
MODIFY `fpc_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `s_formfieldwidget`
--
ALTER TABLE `s_formfieldwidget`
MODIFY `ffw_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `s_formvalidator`
--
ALTER TABLE `s_formvalidator`
MODIFY `fvd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `s_model`
--
ALTER TABLE `s_model`
MODIFY `mdl_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `s_modelfield`
--
ALTER TABLE `s_modelfield`
MODIFY `mdf_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `s_site`
--
ALTER TABLE `s_site`
MODIFY `sit_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `s_theme`
--
ALTER TABLE `s_theme`
MODIFY `thm_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
